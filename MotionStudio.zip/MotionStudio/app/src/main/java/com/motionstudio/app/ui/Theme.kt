package com.motionstudio.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Accent = Color(0xFFFF5C8A)
val Panel = Color(0xFF181B22)
val Bg = Color(0xFF0F1115)

@Composable
fun MotionTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Panel, onSurface = Color(0xFFECEEF3)),
    content = content
)
