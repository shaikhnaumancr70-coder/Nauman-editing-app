package com.motionstudio.app.engine

data class TransformValues(
    val x: Float, val y: Float, val scaleX: Float, val scaleY: Float,
    val rotationDeg: Float, val opacity: Float, val anchorX: Float, val anchorY: Float
)

/** Animatable layer transform; each property has its own track. */
class AnimatedTransform {
    val x = AnimatedProperty(0f)
    val y = AnimatedProperty(0f)
    val scaleX = AnimatedProperty(1f)
    val scaleY = AnimatedProperty(1f)
    val rotationDeg = AnimatedProperty(0f)
    val opacity = AnimatedProperty(1f)
    val anchorX = AnimatedProperty(0.5f)
    val anchorY = AnimatedProperty(0.5f)

    fun valuesAt(timeMs: Long) = TransformValues(
        x.valueAt(timeMs), y.valueAt(timeMs), scaleX.valueAt(timeMs), scaleY.valueAt(timeMs),
        rotationDeg.valueAt(timeMs), opacity.valueAt(timeMs).coerceIn(0f, 1f),
        anchorX.valueAt(timeMs), anchorY.valueAt(timeMs)
    )
}
