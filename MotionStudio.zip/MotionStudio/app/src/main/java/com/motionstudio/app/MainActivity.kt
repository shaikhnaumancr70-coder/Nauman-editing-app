package com.motionstudio.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.motionstudio.app.ui.EditorScreen
import com.motionstudio.app.ui.MotionTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MotionTheme { EditorScreen() } }
    }
}
