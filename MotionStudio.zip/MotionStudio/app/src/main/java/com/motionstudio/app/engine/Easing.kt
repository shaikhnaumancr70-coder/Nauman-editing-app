package com.motionstudio.app.engine

import kotlin.math.abs

/** Easing applied to the segment that STARTS at a keyframe. Maps progress t in [0,1] to eased progress. */
sealed class Easing {
    abstract fun apply(t: Float): Float

    object Linear : Easing() { override fun apply(t: Float) = t }
    /** Value is held until the next keyframe (step). */
    object Hold : Easing() { override fun apply(t: Float) = if (t >= 1f) 1f else 0f }
    object EaseIn : Easing() { private val c = CubicBezier(0.42f, 0f, 1f, 1f); override fun apply(t: Float) = c.apply(t) }
    object EaseOut : Easing() { private val c = CubicBezier(0f, 0f, 0.58f, 1f); override fun apply(t: Float) = c.apply(t) }
    object EaseInOut : Easing() { private val c = CubicBezier(0.42f, 0f, 0.58f, 1f); override fun apply(t: Float) = c.apply(t) }

    /** CSS-style cubic Bezier from (0,0) to (1,1) with handles (x1,y1) and (x2,y2). x handles must be in [0,1]. */
    class CubicBezier(val x1: Float, val y1: Float, val x2: Float, val y2: Float) : Easing() {
        init { require(x1 in 0f..1f && x2 in 0f..1f) { "Bezier x handles must be within [0,1]" } }

        private fun bx(s: Float) = 3 * (1 - s) * (1 - s) * s * x1 + 3 * (1 - s) * s * s * x2 + s * s * s
        private fun by(s: Float) = 3 * (1 - s) * (1 - s) * s * y1 + 3 * (1 - s) * s * s * y2 + s * s * s

        override fun apply(t: Float): Float {
            if (t <= 0f) return 0f
            if (t >= 1f) return 1f
            var lo = 0f; var hi = 1f; var s = t
            repeat(40) {
                s = (lo + hi) / 2f
                val x = bx(s)
                if (abs(x - t) < 1e-6f) return by(s)
                if (x < t) lo = s else hi = s
            }
            return by(s)
        }
    }
}
