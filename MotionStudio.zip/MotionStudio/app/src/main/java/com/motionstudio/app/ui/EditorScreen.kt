package com.motionstudio.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.unit.dp
import com.motionstudio.app.engine.*

/** Phase 1 shell. The preview box is driven by the real keyframe engine (demo clip only). */
@Composable
fun EditorScreen() {
    val demo = remember {
        AnimatedTransform().apply {
            x.setKeyframe(Keyframe(0, 0.15f, Easing.EaseInOut)); x.setKeyframe(Keyframe(2000, 0.85f))
            rotationDeg.setKeyframe(Keyframe(0, 0f, Easing.EaseOut)); rotationDeg.setKeyframe(Keyframe(2000, 180f))
            scaleX.setKeyframe(Keyframe(0, 0.6f)); scaleX.setKeyframe(Keyframe(2000, 1.4f))
            scaleY.setKeyframe(Keyframe(0, 0.6f)); scaleY.setKeyframe(Keyframe(2000, 1.4f))
            opacity.setKeyframe(Keyframe(0, 0.3f)); opacity.setKeyframe(Keyframe(2000, 1f))
        }
    }
    var timeMs by remember { mutableStateOf(0f) }
    val v = demo.valuesAt(timeMs.toLong())

    Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().padding(12.dp)) {
        Text("Motion Studio", color = Accent, style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(12.dp))
        Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(10.dp)).background(Color.Black)) {
            Canvas(Modifier.fillMaxSize()) {
                val s = 90f
                val c = Offset(size.width * v.x, size.height * 0.5f)
                rotate(v.rotationDeg, c) {
                    scale(v.scaleX, v.scaleY, c) {
                        drawRect(Accent.copy(alpha = v.opacity), c - Offset(s / 2, s / 2), Size(s, s))
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Slider(value = timeMs, onValueChange = { timeMs = it }, valueRange = 0f..2000f)
        Text("%.2f s  |  keyframe demo clip (Phase 1)".format(timeMs / 1000f), color = Color(0xFFB4BAC8))
        Spacer(Modifier.height(12.dp))
        Column(Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(10.dp)).background(Panel).padding(16.dp),
            verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Timeline (coming in Phase 2)", color = Color(0xFFB4BAC8))
        }
    }
}
