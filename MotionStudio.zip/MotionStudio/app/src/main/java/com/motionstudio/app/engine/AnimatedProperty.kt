package com.motionstudio.app.engine

/** One keyframe. timeMs is relative to clip start. easing shapes the segment leaving this key. */
data class Keyframe(val timeMs: Long, val value: Float, val easing: Easing = Easing.Linear)

/** One animatable value (e.g. X position). With no keyframes it returns defaultValue. */
class AnimatedProperty(val defaultValue: Float) {
    private val keys = mutableListOf<Keyframe>()
    val keyframes: List<Keyframe> get() = keys.toList()

    fun setKeyframe(k: Keyframe) {
        require(k.timeMs >= 0) { "timeMs must be >= 0" }
        val i = keys.indexOfFirst { it.timeMs == k.timeMs }
        if (i >= 0) keys[i] = k else { keys.add(k); keys.sortBy { it.timeMs } }
    }

    fun removeKeyframeAt(timeMs: Long): Boolean = keys.removeAll { it.timeMs == timeMs }
    fun nextKeyframeAfter(timeMs: Long): Keyframe? = keys.firstOrNull { it.timeMs > timeMs }
    fun previousKeyframeBefore(timeMs: Long): Keyframe? = keys.lastOrNull { it.timeMs < timeMs }

    fun duplicateKeyframe(fromMs: Long, toMs: Long): Boolean {
        val k = keys.firstOrNull { it.timeMs == fromMs } ?: return false
        setKeyframe(k.copy(timeMs = toMs)); return true
    }

    fun clear() = keys.clear()

    fun valueAt(timeMs: Long): Float {
        if (keys.isEmpty()) return defaultValue
        if (timeMs <= keys.first().timeMs) return keys.first().value
        if (timeMs >= keys.last().timeMs) return keys.last().value
        val i = keys.indexOfLast { it.timeMs <= timeMs }
        val a = keys[i]; val b = keys[i + 1]
        val t = (timeMs - a.timeMs).toFloat() / (b.timeMs - a.timeMs).toFloat()
        return a.value + (b.value - a.value) * a.easing.apply(t)
    }
}
