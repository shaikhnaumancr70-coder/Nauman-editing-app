package com.motionstudio.app.engine

import org.junit.Assert.*
import org.junit.Test

class EngineTest {
    private fun prop(e: Easing = Easing.Linear) = AnimatedProperty(0f).apply {
        setKeyframe(Keyframe(0, 0f, e)); setKeyframe(Keyframe(1000, 100f))
    }

    @Test fun noKeyframesReturnsDefault() = assertEquals(5f, AnimatedProperty(5f).valueAt(300), 0f)
    @Test fun linearMidpoint() = assertEquals(50f, prop().valueAt(500), 1e-3f)
    @Test fun clampsBeforeAndAfter() { val p = prop(); assertEquals(0f, p.valueAt(0), 0f); assertEquals(100f, p.valueAt(5000), 0f) }
    @Test fun holdStaysUntilNextKey() { val p = prop(Easing.Hold); assertEquals(0f, p.valueAt(999), 0f); assertEquals(100f, p.valueAt(1000), 0f) }
    @Test fun easeInIsSlowerAtStart() = assertTrue(prop(Easing.EaseIn).valueAt(250) < prop().valueAt(250))
    @Test fun easeOutIsFasterAtStart() = assertTrue(prop(Easing.EaseOut).valueAt(250) > prop().valueAt(250))
    @Test fun easeInOutIsSymmetric() = assertEquals(50f, prop(Easing.EaseInOut).valueAt(500), 0.5f)
    @Test fun bezierLinearHandlesMatchLinear() =
        assertEquals(30f, prop(Easing.CubicBezier(1f / 3, 1f / 3, 2f / 3, 2f / 3)).valueAt(300), 0.1f)
    @Test fun keysStaySortedAndReplace() {
        val p = AnimatedProperty(0f)
        p.setKeyframe(Keyframe(500, 1f)); p.setKeyframe(Keyframe(100, 2f)); p.setKeyframe(Keyframe(500, 9f))
        assertEquals(listOf(100L, 500L), p.keyframes.map { it.timeMs }); assertEquals(9f, p.keyframes[1].value, 0f)
    }
    @Test fun deleteAndNavigate() {
        val p = prop(); assertEquals(1000L, p.nextKeyframeAfter(0)?.timeMs); assertEquals(0L, p.previousKeyframeBefore(1000)?.timeMs)
        assertTrue(p.removeKeyframeAt(1000)); assertNull(p.nextKeyframeAfter(0))
    }
    @Test fun duplicateKeyframe() { val p = prop(); assertTrue(p.duplicateKeyframe(0, 2000)); assertEquals(3, p.keyframes.size) }
    @Test fun opacityClamped() {
        val t = AnimatedTransform(); t.opacity.setKeyframe(Keyframe(0, 2f)); assertEquals(1f, t.valuesAt(0).opacity, 0f)
    }
}
