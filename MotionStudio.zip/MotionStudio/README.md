# Motion Studio (Phase 1 scaffold)

STATUS: written but NOT yet compiled or tested. The authoring sandbox had no Android SDK or network.

## Build from an Android phone
1. Create a private GitHub repo and upload this folders contents (GitHub web UI or github.dev). Keep the .github folder.
2. Repo > Actions > "Build Motion Studio" > latest run.
3. If green, download the MotionStudio-debug-apk artifact, unzip, install the APK.
4. If red, open the failed step and send me the exact error text.

## What exists
- engine/: keyframe model, easing (linear, ease in/out/in-out, hold, custom cubic Bezier), per-property tracks, transform. Unit-tested.
- ui/: dark theme, preview driven by the real engine on a demo clip, scrub slider.

## Not yet implemented
Media import, timeline, trim/split, audio, text, graph editor UI, save/load, export, effects, release signing.
